import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;

public class CrashDriver {
    public static void main(String[] args) throws Exception {

        if (args.length != 2) {
            System.err.println("Usage: CrashDriver <input path> <output path>");
            System.exit(-1);
        }

        JobConf conf = new JobConf(CrashDriver.class);
        conf.setJobName("Motorist Killed by Contributing Factor");

        conf.setMapperClass(CrashMapper.class);
        conf.setReducerClass(CrashReducer.class);
        conf.setCombinerClass(CrashReducer.class);

        conf.setOutputKeyClass(Text.class);
        conf.setOutputValueClass(IntWritable.class);

        conf.setInputFormat(TextInputFormat.class);
        conf.setOutputFormat(TextOutputFormat.class);

        FileInputFormat.setInputPaths(conf, new Path(args[0]));
        FileOutputFormat.setOutputPath(conf, new Path(args[1]));

        JobClient.runJob(conf);
    }
}
