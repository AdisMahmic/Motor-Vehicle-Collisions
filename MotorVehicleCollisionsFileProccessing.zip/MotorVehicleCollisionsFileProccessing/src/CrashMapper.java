import java.io.IOException;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;

public class CrashMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, IntWritable> {

    private boolean isHeader = true;
    private int killedIndex = -1;
    private int factorIndex = -1;

    public void map(LongWritable key, Text value, OutputCollector<Text, IntWritable> output, Reporter reporter) throws IOException {
        String line = value.toString();
        String[] fields = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1); // CSV-safe

        // Handle header row and identify indices
        if (isHeader) {
            for (int i = 0; i < fields.length; i++) {
                String col = fields[i].trim().toUpperCase();
                if (col.equals("NUMBER OF MOTORIST KILLED")) {
                    killedIndex = i;
                } else if (col.equals("CONTRIBUTING FACTOR VEHICLE 1")) {
                    factorIndex = i;
                }
            }
            isHeader = false;
            return;
        }

        // Process rows if indices were found
        if (killedIndex != -1 && factorIndex != -1 && fields.length > Math.max(killedIndex, factorIndex)) {
            try {
                String killedStr = fields[killedIndex].trim();
                String factor = fields[factorIndex].trim();

                int killed = Integer.parseInt(killedStr.isEmpty() ? "0" : killedStr);

                if (!factor.isEmpty() && !factor.equalsIgnoreCase("Unspecified")) {
                    output.collect(new Text(factor), new IntWritable(killed));
                }
            } catch (NumberFormatException e) {
                // skip malformed rows
            }
        }
    }
}
